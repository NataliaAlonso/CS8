#include "stack.h"

stack::stack()
{
}
